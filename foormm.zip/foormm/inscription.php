<?php
$name         = $_POST["name"];
$prename      = $_POST["prename"];



 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Votre candidature a bien été envoyé!</h1>
    <label for="lastname">Votre nom</label>
    <span id="name" > <?=$name?> </span>

    <label for="name">Votre Prénom</label>
    <span id="prename" > <?=$prename?> </span>


  </body>
</html>
